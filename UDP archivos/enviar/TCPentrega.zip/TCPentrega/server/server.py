import socket
import multiprocessing
import os
import time
MAXCONNECTIONS = 80
BUFFER = 1024
TIME_OUT = 10.0
def procesar(data,conn):
        data = data.rstrip()
        print(str(data))
        if 'getdir' in data:
                data = data.split(':')[1]
                lista = os.listdir(data)
                lista2 = [str(x)+':::'+str(os.path.getsize(data+'/'+str(x))) for x in lista]
                myList = ';'.join(map(str, lista2))
                return myList+'\n'
        elif 'getfile' in data:
                data = data.split(':')[1]
                f = open(str(data),'rb')
                l = f.read(BUFFER)
                while l:
                        print 'sending...'
                        conn.send(l)
                        data = conn.recv(BUFFER)
                        if 'ok' in data:
                                l = f.read(BUFFER)
                                print data
                        else:
                                print data
                                f.close()
                                return 'termino\n'
                f.close()
                print 'termino'
                return ''
        else:
                return '\n'
def handle(connection, address, th):
    import logging
    connection.settimeout(TIME_OUT)
logging.basicConfig(level=logging.DEBUG)
    logger = logging.getLogger("process-%r" % (address,))
    try:
        logger.debug("Connected %r at %r", connection, address)
        data = connection.recv(BUFFER)
        can = False
        if 'Holiwi' in data:
                can = True
                print 'entor'
                connection.sendall(data)
        data = connection.recv(BUFFER)
        while can and not 'Adios' in data:
            if data == "":
                logger.debug("Socket closed remotely")
                break
            print data
            logger.debug("Received data %r", data)
            connection.sendall(procesar(data,connection))
            logger.debug("Sent data")
            data = connection.recv(BUFFER)
    except:
        logger.exception("Problem handling request")
        connection.sendall('TIMEOUT\n')
    finally:
        logger.debug("Closing socket")
        connection.close()
        th.value -= 1

class Server(object):
        def __init__(self, hostname, port):
                import logging
                self.logger = logging.getLogger("server")
                self.hostname = hostname
                self.port = port

        def start(self):
                self.logger.debug("listening")
                self.socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                self.socket.bind((self.hostname, self.port))
                self.socket.listen(1)
th = multiprocessing.Value('d',1)
                while True:
                        if th.value <= MAXCONNECTIONS:
                                conn, address = self.socket.accept()
                                th.value += 1
                                self.logger.debug("Got connection")
                                process = multiprocessing.Process(target=handle, args=(conn, address, th))
                                print(th.value)
                                process.daemon = True
                                process.start()
                                self.logger.debug("Started process %r", process)
if __name__ == "__main__":
    import logging
    logging.basicConfig(level=logging.DEBUG)
    server = Server('', 9000)
    try:
        logging.info("Listening")
        server.start()
    except:
        logging.exception("Unexpected exception")
    finally:
        logging.info("Shutting down")
        for process in multiprocessing.active_children():
            logging.info("Shutting down process %r", process)
            process.terminate()
            process.join()
logging.info("All done")

