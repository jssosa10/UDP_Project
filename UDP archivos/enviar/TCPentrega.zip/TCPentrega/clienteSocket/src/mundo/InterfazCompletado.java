package mundo;

import java.io.File;

public interface InterfazCompletado {

	public void completado(File archivoFinal);
}
