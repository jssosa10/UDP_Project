package mundo;

public interface InterfazCanceladora {

	public void cancelar();
}
