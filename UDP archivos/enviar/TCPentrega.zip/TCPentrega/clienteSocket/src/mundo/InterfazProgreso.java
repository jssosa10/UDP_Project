package mundo;

public interface InterfazProgreso {

	public void actualizarProgreso(int porcentaje);
}
