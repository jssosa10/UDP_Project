package mundo;

public interface InterfazEstado {

	public void actualizarEstado(int estado);
}
