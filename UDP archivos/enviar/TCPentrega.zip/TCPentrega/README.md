# TCP_Project
Implementación de un cliente y un servidor para compartir archivos utilizando sockets TCP.
## Autores:
|Nombre| Usuario |Correo|
-------|---------|---------|
|Carlos Mario Sarmiento|[korkies22](https://github.com/korkies22)|cm.sarmiento10@uniandes.edu.co|
|Juan Sebastian Sosa|[jssosa10](https://github.com/jssosa10)|js.sosa10@uniandes.edu.co|
